# XRecife Roleplay API

Endpoints: GET /api/health, POST /api/auth/register, POST /api/auth/login, GET /api/me, GET /api/news, GET /api/app/version.

Render: Build `npm install`; Start `npm start`.
Environment: DATABASE_URL and JWT_SECRET.
SA-MP: 200.9.154.250:7867.
